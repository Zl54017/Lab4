<template>
    <div class="logo">
        <img src="../../assets/logo.png" alt="Moj Logo" width="103" height="75">
    </div>
</template>
